import fitz  # PyMuPDF
from openai import OpenAI

# 1. Récupère le texte depuis un fichier PDF
def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    text = ""
    for page in doc:
        text += page.get_text()
    return text


def build_facts_prompt(user_description, rules):
    return f"""
You are a symbolic reasoning assistant.

Based on the following description, extract all logical facts about a single main entity.

Use the same syntax and predicate names as the following rules:
{rules}

Each fact must follow this format exactly (without any period at the end):
predicate(entity, value)

Where 'entity' is a constant identifier starting with a lowercase letter (e.g., entity, subject, item), **not a variable**.

Use predicates such as: has, is, may_have, require, triggers, located_in, causes, owns, needs, etc.

DO NOT infer conditions that are not explicitly or obviously stated.
DO NOT write anything else besides the facts.
DO NOT add any periods (.) at the end of the facts.
DO NOT use numbering or bullet points.

IMPORTANT:
- Always use a lowercase constant (which described the object or the person) as the entity identifier in your facts.
- Do not use uppercase names in facts; uppercase names are reserved for variables in rules and queries.

Now extract facts from the following description:

\"\"\"{user_description}\"\"\"
"""



# 3. Appeler OpenAI API
def extract_facts_from_prompt(rules, user_description, api_key, model="gpt-4"):
    prompt = build_facts_prompt(user_description,rules)

    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2
    )

    facts = response.choices[0].message.content
    with open("facts.txt","w") as f:
        f.write(facts)

    return response.choices[0].message.content

#  Exemple d’utilisation
if __name__ == "__main__":
    rules_path = "rules.txt"
    with open(rules_path, "r") as f:
        rules = f.read().strip()
    api_key ='sk-proj-lcmDplsiujeMBu5vLzxRT3BlbkFJoiR4pB6jJD7N7qrovnet'
    user_description = """
I've been experiencing persistent coughing for more than a week now, accompanied by a fever above 38°C.
I also have a sore throat, fatigue, and nasal congestion. Recently, I've been feeling short of breath
and experiencing chest pain when I breathe. I've also noticed some confusion and dizziness. I have a history
of allergies and asthma, but I'm not sure if these symptoms are related to that.
"""
    facts=extract_facts_from_prompt(rules,user_description, api_key)
    # print("\nExtracted Facts:\n")
    # print(facts)
