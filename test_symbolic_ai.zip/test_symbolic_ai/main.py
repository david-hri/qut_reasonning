from extract_facts import *
from extract_rules import *
from extract_queries import *

import pytholog as pl

model="gpt-4"

# Création d'une base de connaissances

pdf_path = "Respiratory_Illness_Diagnostic_Guide.pdf"
api_key ='sk-proj-lcmDplsiujeMBu5vLzxRT3BlbkFJoiR4pB6jJD7N7qrovnet'

    
rules = extract_rules_from_pdf(pdf_path, api_key)
rules_path = "rules.txt"
with open(rules_path, "r") as f:
    rules = f.read().strip()
api_key ='sk-proj-lcmDplsiujeMBu5vLzxRT3BlbkFJoiR4pB6jJD7N7qrovnet'
user_description = """
I've been experiencing persistent coughing for more than a week now, accompanied by a fever above 38°C.
I also have a sore throat, fatigue, and nasal congestion. Recently, I've been feeling short of breath
and experiencing chest pain when I breathe. I've also noticed some confusion and dizziness. I have a history
of allergies and asthma, but I'm not sure if these symptoms are related to that.
"""

facts=extract_facts_from_prompt(rules,user_description, api_key) #Construct the facts from the user description and rules
facts_path = "facts.txt"



entities = extract_entities_from_file(facts_path)
extract_conclusions("rules.txt", "queries.txt", entities)





kb = pl.KnowledgeBase("medical")

def load_lines(filename):
    with open(filename, 'r') as f:
        return [line.strip() for line in f if line.strip() and not line.startswith('%')]
    

file = load_lines("queries.txt")

kb(load_lines("facts.txt")+load_lines("rules.txt"))

results=[]
for query in file:
    # Exécute la requête et affiche le résultat
    result = kb.query(pl.Expr(query))
    # print(f"Query: {query} -> Result: {result}")
    if result==['Yes']:
        results.append(f"{query} -> {result}")
        # print(result)



def build_explanation_prompt(user_description, rules, facts, results):
    return f"""
You are a symbolic reasoning assistant that helps explain the reasoning behind a medical diagnostic.

User description:
\"\"\"{user_description.strip()}\"\"\"

Rules used:
\"\"\"{rules.strip()}\"\"\"

Facts extracted:
\"\"\"{facts.strip()}\"\"\"

Results from logical reasoning:
{results}

Write a clear explanation in natural language that summarizes:
- What conditions the patient may have
- Why the system reached these conclusions (based on facts and rules)
- Only mention what is logically concluded from the rules and facts
"""

# Chargement des faits et résultats
with open("facts.txt") as f:
    facts_text = f.read()
    
results_log = ""
for query in file:
    result = kb.query(pl.Expr(query))
    results_log += f"{query} -> {result}\n"

# Construction du prompt
final_prompt = build_explanation_prompt(user_description, rules, facts_text, results_log)

# Appel à l’API OpenAI pour générer la réponse en langage naturel
client = OpenAI(api_key=api_key)
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": final_prompt}],
    temperature=0.2
    )




print("\n Final Answer in Natural Language:\n")
print(response.choices[0].message.content)