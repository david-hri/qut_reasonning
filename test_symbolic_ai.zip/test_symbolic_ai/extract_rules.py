import fitz  # PyMuPDF
from openai import OpenAI

# 1. Récupère le texte depuis un fichier PDF
def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    text = ""
    for page in doc:
        text += page.get_text()
    return text

# 2. Définir le prompt généraliste
def build_prompt(document_text):
    return f"""
You are a symbolic reasoning engine.

Your task is to read a descriptive document and extract logical rules that can be used for reasoning. These rules follow the format of first-order logic or Datalog-style Horn clauses.

Each rule must strictly follow this structure (with no period at the end):
head :- condition1, condition2, ..., conditionN

Where:
- The `head` is a logical conclusion (e.g., may_have(X, pneumonia))
- The conditions are predicates (e.g., has(X, fever), observed(X, risk_factor), owns(X, car))
- Use predicates such as: has, is, may_have, require, triggers, located_in, causes, owns, needs, etc.

Assume X is the main entity (e.g., a person, object, region), and use variables like X, Y if needed.

Only extract logical rules that are implied by the text. Do not copy text literally.

You must strictly follow these output rules:
- Do NOT add any period (.) at the end of any line
- Do NOT number the rules or add bullet points
- Do NOT include any explanation or commentary
- Output ONLY one rule per line, in the format specified

Correct examples (without periods at the end):
may_have(X, respiratory_infection) :- has(X, persistent_cough), has(X, fever_gt_38)
at_risk(X, drought) :- has(X, high_co2), has(X, low_rainfall)
may_trigger(X, security_breach) :- has_access(X, sensitive_data), not(has(X, mfa))

Only extract logical rules. Do not write anything else.

Now extract all rules from the following text:


{document_text[:6000]}
"""


# 3. Appeler OpenAI API
def extract_rules_from_pdf(pdf_path, api_key):
    document_text = extract_text_from_pdf(pdf_path)
    prompt = build_prompt(document_text)

    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2
    )

    with open("rules.txt","w"):
        rules = response.choices[0].message.content
        
        with open("rules.txt","w") as f:
            f.write(rules)
    return response.choices[0].message.content

# 🔁 Exemple d’utilisation
if __name__ == "__main__":
    pdf_path = "Respiratory_Illness_Diagnostic_Guide.pdf"
    api_key ='sk-proj-lcmDplsiujeMBu5vLzxRT3BlbkFJoiR4pB6jJD7N7qrovnet'

    
    rules = extract_rules_from_pdf(pdf_path, api_key)
    print("\nExtracted Rules:\n")
    print(rules)
